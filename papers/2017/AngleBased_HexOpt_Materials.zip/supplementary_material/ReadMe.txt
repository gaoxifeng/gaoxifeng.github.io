# Running only in Linux (Ubuntu14.04)
# Required libraries: vtk-6.3 libigl eigen3
# Modify CMakeLists.txt line 33-41
# There are precompiled binaries in the folder 'bin', you can run examples without
# compiling the code, but you have to install vtk-6.3
# When you install vtk-6.3, please activate the option "VTK_Group_MPI" so that you
# can successfully run the precompiled binaries. See ReadMe.png.

# 1. compile
sh build.sh

# 2. run examples
cd examples/table1/bust/
./run_figure1.sh
./run_table1.sh
cd examples/table2/fandisk/
./run.sh
cd examples/table4/airplane1/
./run.sh
cd examples/table4/blade_octree/
./run.sh

# 3. tools
Use the following command to compute scaled Jacobian
MeshQuality hex.vtk
Use the following command to display a hex-mesh (the number is opacity)
MeshQuality hex.vtk 1
MeshQuality hex.vtk 0.5

# 4. If you want to use metro tools to calculate the Hausdorff distance, please 
# install wine 
