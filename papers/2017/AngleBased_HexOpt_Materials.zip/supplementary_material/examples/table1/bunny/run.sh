./LocalMeshOpt.sh input.vtk input.vtk 0.65 result.vtk 170
