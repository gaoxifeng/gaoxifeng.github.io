Please refer blade_octree for run.sh if you want to test
