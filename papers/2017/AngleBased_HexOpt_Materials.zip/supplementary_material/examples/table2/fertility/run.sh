./LocalMeshOpt.sh input.vtk input.vtk 0.75 result.vtk 165 20
