./LocalMeshOpt.sh input.vtk ref.tet.vtk 0.75 result.vtk 160 20
